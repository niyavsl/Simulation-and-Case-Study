## ----setup_math, cache=FALSE, message=FALSE------------------------------
library("RColorBrewer")
library("Hmisc")
library("gridExtra")
library("palmtree")
set.seed(221)
source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\palmtree.R") # overwrite plotting function for palmtree

## ----lm, results='asis'--------------------------------------------------
rnd <- 2

## load data and scale points achieved to [0, 100] percent
data("MathExam14W", package = "psychotools")
MathExam14W$tests <- 100 * MathExam14W$tests/26
MathExam14W$pcorrect <- 100 * MathExam14W$nsolved/13

MathExam <- MathExam14W[,c("pcorrect", "group", "tests", "study",
                           "attempt", "semester", "gender")]

## first model
bmod0 <- lm(pcorrect ~ group, MathExam)

## second model
bmod <- lm(pcorrect ~ group + tests, MathExam)

## ----palm, fig.show="hide", fig.cap="Math exam PALM tree.", fig.width=10.4, fig.height=8, out.width="1\\textwidth"----
## fit PALM tree to detect potential group effects
## while globally adjusting for math ability prior to the exam
tr <- palmtree(pcorrect ~ group | tests | tests + study +
                 attempt + semester + gender, data = MathExam)

plot(tr, confint = TRUE)

palmmod <- lm(pcorrect ~ 0 + .tree + group:.tree + tests, data = tr$data)

## ----res, out.width="1\\textwidth", fig.width=9, fig.height=5------------

## create tables from models
tab_bmod0 <- as.data.frame(round(cbind(Estimate = coef(bmod0),
                                      confint(bmod0)), rnd))
tab_bmod <- as.data.frame(round(cbind(Estimate = coef(bmod),
                                      confint(bmod)), rnd))
tab_palm <- as.data.frame(round(cbind(Estimate = coef(palmmod),
                                      confint(palmmod)), rnd))
# parameter names for palm model
parm_palm <- row.names(tab_palm)
parm_palm <- gsub(".tree", "node", parm_palm)
numbs <- grepl("node[[:digit:]]$", parm_palm)
parm_palm[numbs] <- paste0(parm_palm[numbs], ":(Intercept)")
row.names(tab_palm) <- parm_palm

## All parameter names
parm <- c("(Intercept)", parm_palm[1:3], "group2", parm_palm[5:7], "tests")

## list of all estimates and confidence intervals
cf_list <- list("Linear model 1" = tab_bmod0[parm, ], 
                 "Linear model 2" = tab_bmod[parm, ], 
                 "PALM tree" = tab_palm[parm, ])

## format the estimates and confidence intervals tables 
format_tab <- function(tab) {
  ft <- function(x) {
    ifelse(all(is.na(x)), 
           "", 
           paste0(format(x[1], nsmall = rnd), "\n [", 
                  format(x[2], nsmall = rnd), ", ", 
                  format(x[3], nsmall = rnd), "]"))
  }
  res <- apply(tab, 1, ft)
  names(res) <- rownames(tab)
  return(res)
}

tab_res <- sapply(cf_list, format_tab)
row.names(tab_res) <- parm


## prepare color coded table
which.color_list <- lapply(cf_list, function(x) apply(sign(x), 1, sum) + 5)
which.color <- do.call(cbind, which.color_list)
mypalette <- brewer.pal(9, "PiYG")
fill_lines <- mypalette[which.color]

tb <- tableGrob(tab_res, 
                theme = ttheme_default(
                  core = list(bg_params = list(fill = fill_lines)),
                  colhead = list(bg_params = list(fill = "white")),
                  rowhead = list(fg_params = list(fontface = "plain"),
                                 bg_params = list(fill = rep("white", times = 4)))
                )
)

## draw table
grid.newpage()
grid.draw(tb)

