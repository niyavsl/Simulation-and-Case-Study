## ----simsetup, echo=FALSE, chache=FALSE----------------------------------
knitr::opts_chunk$set(warning = FALSE)
source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\evaluation.R")
load(file = "C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\simulation_results.R")
res <- subset(results, subset = grepl(pattern = "standard", results$tags))
res$scenario <- gsub(",standard", "", res$tags)
library("ggplot2")
library("gridExtra")

# results$time.running.hours <- as.numeric(results$time.running) / 60 / 60
# ggplot(results, aes(y = time.running.min, x = nobs, color = npc)) + geom_point() +
#   facet_grid(~ type) 


tp <- c("palmtree", "lmtree1", "lmtree2", "otr", "stima")
tp_nam <- c("PALM tree ", "LM tree 1 ", "LM tree 2 ", "OTR ", "STIMA")
l1 <- scale_color_discrete(name = "type",
                           breaks = tp,
                           labels = tp_nam) 
l2 <- scale_linetype_discrete(name = "type",
                              breaks = tp,
                              labels = tp_nam)

## ----fig_nsg-------------------------------------------------------------
# scenarios <- c("a", "b", "c", "d", "e", "f")
changeing <- c("delta_beta", "nobs", "qualitative", "npc", "npred", "nprog")
namchangeing <- c("Delta[beta]", "n", "qualitative", 
                  "# patient characteristics", "# predictive factors", 
                  "# prognostic factors")
nams <- data.frame(changeing, namchangeing, stringsAsFactors = FALSE)

plot_mean_nsubgroups <- function(data, xx) {
  x <- xx["changeing"]
  xnam <- xx["namchangeing"]
  data <- subset(data, scenario %in% c(x, "all"))
  p <- ggplot(data, 
              aes_string(x = x,  y = "nsubgroups", color = "type")) +
    stat_summary(fun.y = "mean", geom = "point", show.legend = FALSE) + 
    stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) + 
    scale_x_continuous(breaks = unique(data[[x]])) +
    ylab("# subgroups") + xlab(xnam) +
    l1 + l2
  if(x != "npred") p <- p + geom_hline(yintercept = 3, alpha = 0.2)
  if(x == "delta_beta") p <- p + xlab(expression(Delta[beta]))
  p
}


plot_mean_ari <- function(data, xx) {
  x <- xx["changeing"]
  xnam <- xx["namchangeing"]
  data <- subset(data, scenario %in% c(x, "all"))
  p <- ggplot(data, aes_string(x = x,  y = "ari", color = "type")) +
    stat_summary(fun.y = "mean", geom = "point", show.legend = FALSE) +
    stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) +
    coord_cartesian(ylim = c(0, 1)) +
    scale_x_continuous(breaks = unique(data[[x]])) +
    ylab("ARI") + xlab(xnam) +
    l1 + l2
  if(x == "delta_beta") p <- p + xlab(expression(Delta[beta]))
  p
}


## ----eval = FALSE, echo = FALSE------------------------------------------
## # a <- res[res$type == "lmtree1", ]
## # ggplot(a, aes(x = delta_beta, y = nsubgroups, color = scenario)) + geom_jitter(alpha = 0.2) +
## #   facet_grid(~ scenario)

## ----fig_nsg1, fig.cap = "Mean number of subgroups and mean ARI for varying $\\Delta_\\beta$ and number of observations (Question~\\ref{sec:simsg})."----
p_mean_subgroups <- apply(nams, 1, plot_mean_nsubgroups, data = res)
p_mean_ari <- apply(nams[1:2, ], 1, plot_mean_ari, data = res)
do.call(grid_arrange_shared_legend, append(p_mean_subgroups[1:2], p_mean_ari))

## ----fig_nsg2, fig.cap = "Mean number of subgroups for varying types of subgroups (quantitative/qualitative), number of patient characteristics, predictive factors and prognostic factors (Question~\\ref{sec:simsg})."----
do.call(grid_arrange_shared_legend, p_mean_subgroups[3:6])

## ----max_nsg-------------------------------------------------------------
library("plyr")
maxnsg <- ddply(res, .(type), function(r) r[which.max(r$nsubgroups), ])

## ----fig_size, out.width="0.65\\textwidth", fig.width=5, fig.height=2.7, fig.align='center', fig.cap="Proportion of trees with more than one subgroup for varying number of observations (Question~\\ref{sec:simerr1}). Black line at 0.05."----
g <- ggplot_build(p_mean_ari[[1]])
colors <- unique(g$data[[2]]$colour)
linetypes <- unique(g$data[[2]]$linetype)
led <- data.frame(type = tp, colors, linetypes, stringsAsFactors = FALSE)


nopred <- subset(results, tags == "null_varnobs")
prop_wrong <- function(x) sum(x$nsubgroups > 1)/nrow(x)


library("plyr")
sev <- ddply(nopred, .(type, nobs), prop_wrong)
sh <- c("palmtree", "lmtree2", "stima")
sev_sub <- subset(sev, type %in% sh)

ggplot(sev_sub,
       aes(x = nobs, y = V1)) + 
  geom_hline(yintercept = 0.05) +
  geom_point(aes(color = type), show.legend = FALSE) +
  geom_line(aes(linetype = type, color = type)) +
  ylab("Prop. trees > 1 subgroup") + xlab("n") +
  theme(legend.title = element_blank(), legend.position="bottom") +
  scale_x_continuous(breaks = unique(sev[, "nobs"])) + 
  scale_colour_manual(breaks = tp,
                      labels = tp_nam,
                      values = led$colors[led$type %in% sh]) +
  scale_linetype_manual(breaks = tp,
                        labels = tp_nam, 
                        values = led$linetypes[led$type %in% sh])



## ----fig_cortrt, fig.height=3.5, fig.cap="Proportion of observations in all trees where better treatment is correctly identified (Question~\\ref{sec:simotr})."----
plot_prop_corrtrt <- function(data, xx) {
  x <- xx["changeing"]
  xnam <- xx["namchangeing"]
  data <- subset(data, scenario %in% c(x, "all"))
  p <- ggplot(data, aes_string(x = x,  y = "prop_corrtrt", color = "type")) +
    stat_summary(fun.y = "mean", geom = "point", size = 1, show.legend = FALSE) +
    stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) + 
    scale_x_continuous(breaks = unique(data[[x]])) +
    ylim(NA, 1) +
    ylab("Proportion correct treatment") + 
    xlab(xnam) +
    l1 + l2
  if(x == "delta_beta") p <- p + xlab(expression(Delta[beta]))
  p
}

p_prop_corrtrt <- apply(nams[c(1, 5),], 1, plot_prop_corrtrt, data = res)
do.call(grid_arrange_shared_legend, p_prop_corrtrt)

## ----fig_trteff, fig.height=3.5, fig.cap="Mean absolute difference between true and estimated treatment effect (mean absolute error, MAE; Question~\\ref{sec:simest}).", message=FALSE----
# get right colors and linetypes
tpoo <- c("palmtree", "lmtree1", "lmtree2", "stima")
tpoo_nam <- c("PALM tree ", "LM tree 1 ", "LM tree 2 ", "STIMA")

plot_err <- function(data, xx) {
  x <- xx["changeing"]
  xnam <- xx["namchangeing"]
  data <- subset(data, scenario %in% c(x, "all"))
  data <- subset(data, !is.na(mean_benefitpred_err_absolute))
  p <- ggplot(data, aes_string(x = x,  y = "mean_benefitpred_err_absolute", color = "type")) +
    stat_summary(fun.y = "mean", geom = "point", size = 1, show.legend = FALSE) +
    stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) + 
    scale_x_continuous(breaks = unique(data[[x]])) +
    ylab(expression(MAE(beta))) +
    xlab(xnam) +
    l1 + l2
  if(x == "delta_beta") {
    p <- p + xlab(expression(Delta[beta]))
  } 
  
  # adding the correct legend
  p + scale_colour_manual(values = led$colors[led$type != "otr"], 
                          name = "type",
                          breaks = tpoo,
                          labels = tpoo_nam) +
    scale_linetype_manual(values = led$linetypes[led$type != "otr"], 
                          name = "type",
                          breaks = tpoo,
                          labels = tpoo_nam)
}
p_err <- apply(nams[c(1, 5),], 1, plot_err, data = res)
do.call(grid_arrange_shared_legend, p_err)


