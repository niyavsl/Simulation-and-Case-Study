## ----cache=FALSE, message=FALSE, echo=FALSE------------------------------
library("ggplot2")
library("gridExtra")
library("plyr")
library("data.table")
knitr::opts_chunk$set(echo = FALSE, cache = TRUE, warning = FALSE, message = FALSE)
tp <- c("palmtree", "lmtree1", "lmtree2", "otr", "stima")
tp_nam <- c("PALM tree ", "LM tree 1 ", "LM tree 2 ", "OTR ", "STIMA")
l1 <- scale_color_discrete(name = "type",
                           breaks = tp,
                           labels = tp_nam) 
l2 <- scale_linetype_discrete(name = "type",
                              breaks = tp,
                              labels = tp_nam)

## ----a-setup-------------------------------------------------------------
load(file = "analysis/sim_results.RData")
ra <- subset(results, subset = (repl %in% 1:2) & npred > 0) # maybe repl %in% 1:2?

pars <- c("delta_beta", "nobs", "qualitative", "npc", "npred", "nprog")
prs <- unique(ra[, ..pars])
nvls <- sapply(prs, function(x) length(unique(x)))


#table(ra$type)

labf <- function(labels) {
  labels <- label_value(labels, multi_line = TRUE)
  ret <- lapply(unname(labels), lapply, function(label) {
    if(grepl("#", label)) as.character(label)
    else c(parse(text = as.character(label)))
  })
  return(ret)
}

plot_estim <- function(dat, vline = 0) {
  
  ggplot(dat, aes(y = type1, x = estimate, color = type)) +
    geom_vline(xintercept = vline, color = "gray") + 
    geom_errorbarh(aes(xmin = conf.low, xmax = conf.high), height = 0.1) +
    geom_point() +
    facet_wrap(~ var1, scales = "free", labeller = "labf") +
    theme(legend.position = "none", axis.title.y = element_blank(),
          strip.text.x = element_text(face = "plain")) +
    scale_x_continuous(breaks = scales::pretty_breaks(n = 4))
}

## ----fullf1, fig.cap = "Mean ARI in the full factorial design with two simulated data sets per design (Question 3.1).", fig.height=7, fig.width=7----
sub_ra <- subset(ra, (nobs %in% c(100, 500)) & 
                   (npred %in% c(1, 3, 4)) &
                   (npc %in% c(10, 50)))

lab_nobs <- c("100" = "n = 100", "300" = "n = 300", "500" = "n = 500", "900" = "n = 900")
lab_qualitative <- c("0" = "quantitative", "1" = "qualitative")
lab_npred <- c("1" = "1 predictive factor", "3" = "3 predictive factors", 
               "4" = "4 predictive factors")
p_ari <- ggplot(sub_ra, aes(x = delta_beta,  y = ari, color = type)) +
  stat_summary(fun.y = "mean", geom = "point", show.legend = FALSE) +
  stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) +
  scale_x_continuous(breaks = unique(ra$delta_beta)) +
  ylab("ARI") +
  l1 + l2 + xlab(expression(Delta[beta])) +
  facet_grid(nobs * qualitative ~ npred, 
             labeller = labeller(nobs = lab_nobs, 
                                 qualitative = lab_qualitative,
                                 npred = lab_npred))
p_ari

## ----fullf2, fig.cap = "Proportion of observations in all trees where better treatment is correctly identified in the full factorial design with two simulated data sets per design (Question~\\ref{sec:simotr}).", fig.height=7, fig.width=7----
ra$delta_beta1 <- paste("Delta[beta] ==", ra$delta_beta)
ra_1 <- subset(ra, (delta_beta %in% c(0.5, 1.5)) &
                 (nobs %in% c(100, 300)))
ggplot(ra_1, aes(x = npred, y = prop_corrtrt, color = type)) + 
  stat_summary(fun.y = "mean", geom = "point", show.legend = FALSE) +
  stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) +
  facet_grid(qualitative * nobs ~ delta_beta1,
             labeller = labeller(nobs = lab_nobs, 
                                 qualitative = lab_qualitative,
                                 delta_beta1 = label_parsed)) + 
  l1 + l2 + ylab("Proportion correct treatment") + xlab("# predictive factors")

## ----fullf3, fig.cap = "Mean absolute difference between true and estimated treatment effect (mean absolute error, MAE) in the full factorial design with two simulated data sets per design (Question~\\ref{sec:simest}).", fig.height=7, fig.width=7, message = FALSE----
g <- ggplot_build(p_ari)
colors <- unique(g$data[[2]]$colour)
linetypes <- unique(g$data[[2]]$linetype)
led <- data.frame(type = tp, colors, linetypes, stringsAsFactors = FALSE)
ra_2 <- subset(ra, (delta_beta %in% c(0.5, 1.5)) &
                 (nobs %in% c(100, 300)) &
                 (type != "otr"))

ggplot(ra_2,
       aes(x = npred, y = mean_benefitpred_err_absolute, color = type)) + 
  stat_summary(fun.y = "mean", geom = "point", show.legend = FALSE) +
  stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) +
  facet_grid(qualitative * nobs ~ delta_beta1,
             labeller = labeller(nobs = lab_nobs, 
                                 qualitative = lab_qualitative,
                                 delta_beta1 = label_parsed)) + 
  l1 + l2 + ylab(expression(MAE(beta))) + xlab("# predictive factors") +
  scale_colour_manual(breaks = tp,
                      labels = tp_nam,
                      values = led$colors[led$type != "otr"]) +
  scale_linetype_manual(breaks = tp,
                        labels = tp_nam, 
                        values = led$linetypes[led$type != "otr"])

## ----fullf4, fig.cap = "Mean absolute difference between true and estimated treatment effect (mean absolute error, MAE) in the full factorial design with two simulated data sets per design (Question~\\ref{sec:simest}). Limited data to scenarios with 900 observations and one prognostic factor.", out.width="0.65\\textwidth", fig.width=5, fig.height=2.7, fig.align='center', message = FALSE----
ra_3 <- subset(ra, (nobs %in% 900) &
                 (nprog %in% 1))

ggplot(ra_3, aes(x = delta_beta, y = mean_benefitpred_err_absolute, color = type))+ 
  stat_summary(fun.y = "mean", geom = "point", show.legend = FALSE) +
  stat_summary(fun.y = "mean", geom = "line", aes(linetype = type)) + 
  l1 + l2 + ylab(expression(MAE(beta))) + xlab("# predictive factors") +
  scale_colour_manual(breaks = tp,
                      labels = tp_nam,
                      values = led$colors[led$type != "otr"]) +
  scale_linetype_manual(breaks = tp,
                        labels = tp_nam, 
                        values = led$linetypes[led$type != "otr"])

## ----ct------------------------------------------------------------------
ct <- ddply(ra, .(type), function(x)
  quantile(x$time.running)
)
ct$type <- factor(ct$type, labels = tp_nam)

stm <- ct[ct$type == "STIMA", "100%"]
units(stm) <- "hours"
stm_n <- as.numeric(stm)

## ----ct_tab, results="asis"----------------------------------------------
library("Hmisc")
names(ct)[1] <- ""
latex(ct, caption = "Quantiles of computation times per algorithm in seconds.",
      ctable = FALSE, file = "", where = "h", 
      rowname = NULL, first.hline.double = FALSE)

