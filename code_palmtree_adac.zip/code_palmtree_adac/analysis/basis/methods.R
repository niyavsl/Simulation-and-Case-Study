## ----sim_apply_prep, eval=run_code, echo=show_code, warning=show_warn----


as.party.rt <- function(x, dat, ...)
{
  rtobj <- x
  trunk <- rtobj$trunk
  rows <- as.numeric(rownames(trunk))
  
  n1 <- log2(rows)
  n2 <- order(n1 - floor(n1))
  trunk <- trunk[n2,]
  
  rtframe <- data.frame(matrix(0, nrow(trunk), 8))
  colnames(rtframe)<-c("var", "n", "wt", "dev", "yval", "complexity", "ncompete", "nsurrogate")
  rownames(rtframe)<-rownames(trunk)
  
  varnr=as.numeric(rownames(trunk))
  vars=trunk[,1]
  vars[trunk[,6]!=""]<-"<leaf>"
  vars[trunk[,6]==""]<-trunk[varnr%%2==0,1]
  
  rtframe[,1]<-factor(vars)
  rtframe[,2]<-trunk[,4]
  rtframe[,3]<-trunk[,4]
  rtframe[,4]<-0
  rtframe[,5]<-as.numeric(trunk[,5])
  
  #Create splits.
  rtsplits<-matrix(0,nrow=length(vars[varnr%%2==0]),ncol=5,
                   dimnames=list(vars[vars!="<leaf>"],
                                 c("count","ncat","improve","index","adj")))
  rtsplits[,1]<-as.numeric(trunk[vars!="<leaf>",4])
  # -1 means <, 2 means =.
  rtsplits[,2]<- -1
  rtsplits[,4]<-as.numeric(trunk[varnr%%2==0,3])
  
  ## handle categorical first split correctly
  dat_a <- dat[[rownames(rtsplits)[1]]]
  if(is.factor(dat_a)) {
    rtsplits[1,2] <- length(levels(dat_a))
    rtsplits[1,4] <- 1
    rtcsplit <- matrix(c(1L, 3L), ncol = 2L)
  } else {
    rtcsplit <- NULL
  }
  
  rpObj1<-list(frame=rtframe,splits=rtsplits, csplit = rtcsplit)
  class(rpObj1)<-"rpart"
  rpObj1$terms <- terms(as.formula(paste(names(dat)[1], "~ .")), data = dat)
  rpObj1$call <- as.call(parse(text = paste0("rpart(formula = ", names(dat)[1], " ~ ., data = ", 
                                             deparse(substitute(dat)), ")")))[[1]]
  as.party(rpObj1)
}

comp_stima <- function(data) {
  znam <- grep("x", names(data), value = TRUE)
  selvars <- c("y", "a", znam)
  dat <- data[, selvars]
  
  ## compute stima
  tr_full <- stima(data = dat, maxsplit = 6, 
                   model = "regtrunk", first = 2, Save = TRUE)
  ## prune
  rt <- prune(tr_full, data = dat, Save = TRUE)
  if(is.null(rt)) rt <- stima(data = dat, maxsplit = 1, 
                              model = "regtrunk", first = 2, Save = TRUE)
  
  ## set up regressor matrix
  x <- rownames(rt$full)
  x <- x[!grepl("^R[0-9]", x)]
  x <- x[x != "(Intercept)"]
  x <- as.formula(paste("~", paste(x, collapse = " + ")))
  x <- model.matrix(x, data = dat)
  
  ## regression coefficients and adjusted response
  b <- rt$full[colnames(x), 1]
  dat$y <- dat$y - x %*% b
  
  ## create stima party object
  p <- as.party(rt, dat)
  return(p)
}

#' 
#' #' Compute ctree for otr
#' #'
#' #' Checks if all YinternalY are 1. If so create root node.
#' #' Otherwise compute tree.
#' #'
#' #' @param formula formula.
#' #' @param data data set.
#' #' @param weights weights.
#' #' @param control ctree_control.
#' #' @param ... further arguments passed to ctree_control.
#' #'
#' #' @return An object of class party. 
#' newctree <- function(formula, data, weights, control, ...) {
#'   if(all(data$YinternalY == 1)) {
#'     root <- partynode(id = 1L)
#'     tr <- party(root, 
#'                 data = data, 
#'                 fitted = data.frame("(fitted)" = fitted_node(root, data),
#'                                     "(response)" = data$YinternalY))
#'   } else {
#'     data$we <- round(as.vector(weights) * 10000)
#'     tr <- ctree(formula = formula, data = data, weights = we, control = control, ...)
#'   }
#' }


#' rpart with pruning for otr
#'
#' @param formula formula.
#' @param data data set.
#' @param method rpart method. This will for otr usually be "class".
#' @param control rpart.control.
#' @param ... further arguments passed to rpart.control.
#'
#' @return An object of class rpart.
newrpart <- function(formula, data, method, control, ...) {
  tr <- rpart(formula = formula, data = data, method = method, control = control, ...)
  cp_opt <- tr$cptable[which.min(tr$cptable[,"xerror"]), "CP"]
  prune(tr, cp = cp_opt)
}



#' glmtree so that otr won't complain
#' 
#' If all YinternalY are 1, construct root node, otherwise compute glmtree.
#'
#' @param formula formula.
#' @param data data set.
#' @param weights weights.
#' @param minsplit see mob_control.
#' @param family family. In otr usually Binomial.
#' @param caseweights Should weights be interpreted as case weights? For otr FALSE.
#' @param ... passed to mob_control.
#'
#' @return An object of class glmtree inheriting from modelparty.
newglmtree <- function(formula, data, weights, minsplit, family, caseweights, ...) {
  if(all(data$YinternalY == 1)) {
    root <- partynode(id = 1L)
    tr <- party(root, 
                data = data, 
                fitted = data.frame("(fitted)" = fitted_node(root, data),
                                    "(response)" = data$YinternalY))
  } else {
    data$weights <- as.vector(weights)
    glmtree(formula = formula, data = data, weights = weights, minsplit = minsplit, 
            family = family, caseweights = caseweights, ...)
  }
}





#' Compute optimal treatment regimes (otr) 
#'
#' See optmalClass
#'
#' @param data data.
#' @param classifier one of "rpart" or "glmtree".
#'
#' @return Object that inherits directly from class DynTxRegime. 
comp_otr <- function(data, classifier = "rpart") {
  
  fmlax <- as.formula(paste("~", paste(grep("x", names(data), value = TRUE), collapse = " + ")))
  fmlaprog <- as.formula(paste("~", paste0("x", 
                                           attr(data, "simulation")$which_prog, 
                                           collapse = " + ")))
  
  ## propensity is fixed to offs 
  mod_propen <- buildModelObj(model =  ~ offset(qlogis(offs)) - 1, 
                              solver.method = 'glm', 
                              solver.args = list('family' = 'binomial', 
                                                 'y' = FALSE, 
                                                 'model' = FALSE),
                              predict.method = 'predict.glm',
                              predict.args = list(type = 'response'))
  
  ## outcome model
  mod_main <- buildModelObj(model = fmlaprog,
                            solver.method = 'lm',
                            solver.args = list('y' = FALSE, 'model' = FALSE))
  mod_cont <- buildModelObj(model = fmlax,
                            solver.method = 'lm',
                            solver.args = list('y' = FALSE, 'model' = FALSE))
  
  ## classification model
  if(classifier == "rpart") {
    mod_class <- buildModelObj(model = fmlax,
                               solver.method = 'newrpart',
                               solver.args = list(method = "class",
                                                  control = rpart.control(minsplit = 40)),
                               predict.args = list(type = 'class'))
  } else {
    mod_class <- buildModelObj(model = fmlax,
                               solver.method = 'newglmtree',
                               solver.args = list(family = binomial, 
                                                  caseweights = FALSE, 
                                                  minsplit = 40),
                               predict.args = list(type = 'response'))
  }
  
  
  data$offs <- 0.5 
  data$a <- as.integer(as.character(data$a))
  optimalClass(moPropen = mod_propen,
               moMain = mod_main,
               moCont = mod_cont,
               moClass = mod_class,
               data = data,
               response = data$y,
               txName = "a",
               iter = 0,
               suppress = TRUE)
}



#' Compute lasso for treatment interactions.
#' 
#' See cv.glmnet
#'
#' @param data data.
#'
#' @return An object of class "cv.glmnet".
comp_lasso <- function(data) {
  
  xnam <- grep("x", names(data), value = TRUE)
  fmprog <- paste0("x", attr(data, "simulation")$which_prog, 
                   collapse = " + ")
  fmla <- as.formula(paste("y ~ a +", fmprog, 
                           paste(" + a :", xnam, collapse = "")))
  dx <- model.matrix(fmla, data = data)
  dx <- dx[, colnames(dx) != "(Intercept)"]
  
  
  pfac <- rep(1, ncol(dx))
  pfac[colnames(dx) == "x5"] = 0 # no penalty for x5
  
  cv.glmnet(x = dx, y = data$y, alpha = 1, penalty.factor = pfac)
  
}




#' Compute palmtree or lmtree for subgroup analyses with
#' prognostic factors
#'
#' @param data data.
#' @param method one of "palmtree" or "lmtree".
#' @param v version. 1 treats possibly prognostic and predictive factors the
#' same way. 2 adds the prognostic factors in the model and uses the paramters
#' also for splitting
#' @param ... further arguments passed to method.
#'
#' @return palmtree or lmtree
comp_tree <- function(data, method = "palmtree", v = 1, ...) {
  
  which_prog <- attr(data, "simulation")$which_prog
  
  if(length(which_prog) > 0) {
    fmprog <- paste0("x", which_prog, collapse = " + ")
    if(method == "palmtree") behinda <- paste("|", fmprog, "|")
    if(method == "lmtree" & v == 1) behinda <- "|"
    if(method == "lmtree" & v == 2) behinda <- paste("+", fmprog, "|")
  } else {
    stop("In this case all trees do the same. Don't do this.")
  }
  
  z <- grep("x", names(data), value = TRUE) 
  fmla <- as.formula(paste("y ~ a", behinda, paste(z, collapse = "+")))
  
  do.call(method, args = list(formula = fmla, data = data, ...))
  
}

