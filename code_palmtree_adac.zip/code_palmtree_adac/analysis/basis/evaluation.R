
#' Get evaluation of method
#'
#' Comput number of subgroups, ARI, error and proportion of correct treatment
#' assignments.
#'
#' @param mod the model (palmtree, lmtree or otr).
#' @param newdata validation data set.
#' @param method method used ("palmtree", "lmtree" or "otr").
#'
#' @return number of subgroups, ARI, error and proportion of correct treatment
get_evaluations <- function(mod, newdata, method) {
  newdata0 <- newdata1 <- newdata
  newdata0$a[newdata0$a == 1] <- 0
  newdata1$a[newdata1$a == 0] <- 1
  
  ## number of subgroups
  nsubgroups <- switch(method, 
                       palmtree = width(mod$tree),
                       lmtree = width(mod),
                       otr = length(unique(classif(mod)@fitObj$where)) + 1,
                       stima = width(mod[[1]]$node$kids[[1]]) * 
                         width(mod[[1]]$node$kids[[2]]))
  
  
  
  ## ari
  est_group <- switch(method,
                      otr = {
                        tr_fake <- mod@classif@fitObj
                        tr_fake$frame$yval <- as.numeric(rownames(tr_fake$frame))
                        predict(tr_fake, newdata = newdata, type = "vector")
                      },
                      stima = {
                        g0 <- predict(mod, newdata0, type = "node")
                        g1 <- predict(mod, newdata1, type = "node")
                        interaction(g0, g1)
                      },
                      predict(mod, newdata = newdata, type = "node")
  )
  true_group <- newdata$group
  ari <- adj_rand_index(true_group, est_group)
  
  ## mberr + prop correct treatment
  if(method == "otr") {
    # mberr
    mberr <- data.frame(mean_benefitpred_err_raw = NA, 
               mean_benefitpred_err_absolute = NA) 
    
    # correct treatment
    if(is.null(newdata)) stop("For OptimalClass objects newdata may not be NULL")
    hatg_opt <- round(as.numeric(predict(classif(mod), newdata = newdata)))
    
  } else {
    pr1 <- predict(mod, newdata = newdata1, type = "response")
    pr0 <- predict(mod, newdata = newdata0, type = "response")
    pr10 <- pr1 - pr0
    
    # mberr
    mu10 <- newdata$mu1 - newdata$mu0
    mu10pr10 <- mu10 - pr10
    mberr <- data.frame(mean_benefitpred_err_raw = mean(mu10pr10), 
               mean_benefitpred_err_absolute = mean(abs(mu10pr10)))
    
    # correct treatment
    hatg_opt <- as.numeric(pr10 > 0)
  }
  # prop correct treatment
  g_opt <- as.numeric(newdata$trt_effect > 0)
  prop_corrtrt <- mean(hatg_opt == g_opt)
  
  # ## prop correct treatment
  # res <- data.frame(hatg_opt = predict_g_opt(mod, newdata = newdata),
  #                   g_opt = as.numeric(newdata$trt_effect > 0))
  # is_g_opt <- res$hatg_opt == res$g_opt
  # prop_corrtrt <- mean(is_g_opt)
  
  ## return
  c(nsubgroups = nsubgroups, ari = ari, mberr, prop_corrtrt = prop_corrtrt)
}


#' Predict the optimal treatment from a palmtree, (g)lmtree, OptimalClass or cv.glmnet.
#'
#' @param x object of class palmtree, (g)lmtree, OptimalClass or cv.glmnet.
#' @param newdata an optional data frame in which to look for variables with 
#'        which to predict. If NULL, the training data is used.
#' @param df a logical indicating whether just the predicted optimal treatment
#'        should be returned or a data frame including also the true optimal
#'        treatment, the true marginally optimal treatment and the node.
predict_g_opt <- function(x, newdata = NULL, df = FALSE) {
  
  if("OptimalClass" %in% class(x)) { ### otr
    
    if(is.null(newdata)) stop("For OptimalClass objects newdata may not be NULL")
    
    hatg_opt <- round(as.numeric(predict(classif(x), newdata = newdata)))
    pr_node <- NA
    
  } 
  
  if("cv.glmnet" %in% class(x)) { ### lasso
    
    d1 <- newdata
    d1$a <- 1
    
    xnam <- grep("x", names(d1), value = TRUE)
    fmla <- as.formula(paste("y ~ + a + ", paste("a *", xnam, collapse = " + ")))
    dx <- model.matrix(fmla, data = d1)
    dx1 <- dx[, colnames(dx) != "(Intercept)"]
    dx0 <- dx1
    dx0[, grepl("a", colnames(dx0))] <- 0
    
    y1 <- predict(x, dx1, s = "lambda.min")
    y0 <- predict(x, dx0, s = "lambda.min")
    
    hatg_opt <- as.numeric( y1 > y0 )
    
  }
  
  if(any(grepl("tree", class(x)))) { ### mob 
    
    if(is.null(newdata)) newdata <- x$data
    
    ## predict subgroup (terminal node) for every patient
    pr_node <- predict(x, newdata = newdata, type = "node")
    
    ## get treatment effect in groups
    cf <- coef(x)
    if(is.matrix(cf)) {
      cf_trt <- cf[ , grep("a1", colnames(cf))]
    } else {
      cf_trt <- cf[grep("a1", names(cf))]
    }
    
    ## get optimal treatment in each group
    hatg_opt_group <- as.numeric(cf_trt > 0)
    if(length(hatg_opt_group) > 1) {
      names(hatg_opt_group) <- gsub(".tree|:a1", "", names(cf_trt))
    } else {
      names(hatg_opt_group) <- "1"
    }
    
    ## determine optimal treatment for each patient
    hatg_opt <- hatg_opt_group[as.character(pr_node)]
    
  }
  
  if(df) {
    data.frame(g_opt = newdata$gopt, 
               a_opt = median(newdata$gopt),
               hatg_opt = hatg_opt, 
               is_g_opt = newdata$gopt == hatg_opt,
               node = pr_node)
  } else {
    hatg_opt
  }
  
}


#' From a list of lists of palmtrees, (g)lmtrees, OptimalClass' and cv.glmnets
#' check for one of the methods and element j if the treatment regime is correct 
#'
#' @param j index for element in list of methods and data.frames.
#' @param type method. Names of the list elements.
#' @param all_methods list of lists of palmtrees, (g)lmtrees, OptimalClass' and cv.glmnets.
#' @param all_dat list of data.frames on which the methods were computed or (better) a corresponding
#' test data set.
#'
#' @return vector of logicals indicating if the optimal treatment regime was predicted
#' for each patient.
get_is_g_opt <- function(j, type, all_methods, all_dat) {
  res <- data.frame(hatg_opt = predict_g_opt(all_methods[[type]][[j]], newdata = all_dat[[j]]),
                    g_opt = as.numeric(all_dat[[j]]$trt_effect > 0))
  is_g_opt <- res$hatg_opt == res$g_opt
  return(is_g_opt)
}





#' Difference between true and estimated coefficients
#'
#' @param x bject of class palmtree, (g)lmtree or cv.glmnet.
#' @param newdata data.
#' @param all_info logical. Return all info (cbind(newdata, coef_true, coef_est, coef_diff)) or just coef_diff.
#'
#' @return data.frame
diff_coefs <- function(x, newdata = NULL, all_info = TRUE) {
  
  if(is.null(newdata)) newdata <- x$data
  info <- attr(newdata, "simulation")
  
  ## estimated coefficients for each patient
  if("palmtree" %in% class(x)) {  ## palmtree
    
    tnode <- predict(x, newdata = newdata, type = "node")
    
    pc <- coef(x, "palm")
    tc <- coef(x, "tree")
    depth <- depth(x$tree)
    if(depth > 0) {
      coef_ext_gr <- tc[as.character(tnode), ]
    } else {
      coef_ext_gr <- t(as.matrix(tc))[tnode, ]
    }
    row.names(coef_ext_gr) <- NULL
    coef_est <- cbind(coef_ext_gr, as.data.frame(t(pc)))
    
  } 
  
  if("lmtree" %in% class(x)) {  ## lmtree
    
    tnode <- predict(x, newdata = newdata, type = "node")
    
    tc <- coef(x)
    depth <- depth(x)
    if(depth > 0) {
      coef_est <- as.data.frame(tc[as.character(tnode), ])
      row.names(coef_est) <- NULL
    } else {
      coef_est <- matrix(tc, byrow = TRUE,
                         nrow = nrow(newdata), ncol = length(tc),
                         dimnames = list(NULL, names(tc)))
    }
    
  }
  
  if("cv.glmnet" %in% class(x)) {  ## glmnet
    
    coef_glmnet <- coef(x, s = "lambda.min")
    
    xnam <- grep("x", names(newdata), value = TRUE)
    fmla <- as.formula(paste("y ~  a +", paste("a *", xnam, collapse = " + ")))
    dx <- model.matrix(fmla, data = newdata)
    dx <- dx[, grep("a1:x", colnames(dx), value = TRUE)]
    
    cfs <- c("(Intercept)", "a1", "x5")
    coef_est <- matrix(coef_glmnet[cfs, ], byrow = TRUE,
                       nrow = nrow(newdata), ncol = length(cfs),
                       dimnames = list(NULL, cfs))
    coef_est[, "a1"] <- coef_est[, "a1"] + dx %*% coef_glmnet[colnames(dx), ]
    
  }
  
  ## true coefficients for each patient
  coef_true_x <- rep(c(info$eff_prog, 0), times = c(info$nprog, 2-info$nprog))
  coef_true <- cbind("(Intercept)" = 0, 
                     a1 = as.vector(newdata$trt_effect),
                     x5 = coef_true_x[1], 
                     x6 = coef_true_x[2])
  
  ## difference
  cnams <- colnames(coef_est)
  coef_diff <- coef_true[, cnams] - coef_est[, cnams]
  colnames(coef_diff) <- paste0(colnames(coef_diff), "_coef_diff")
  
  
  if(all_info) {
    colnames(coef_true) <- paste0(colnames(coef_true), "_coef_true")
    colnames(coef_est) <- paste0(colnames(coef_est), "_coef_est")
    
    ret <- cbind(newdata, coef_true, coef_est, coef_diff)
  } else {
    ret <- as.data.frame(coef_diff)
  }
  
  names(ret) <- gsub("\\(|\\)", "", names(ret))
  return(ret)
}




#' Share a legend between multiple plots using grid.arrange
#' 
#' From http://rpubs.com/sjackman/grid_arrange_shared_legend
#'
#' @param ... ggplot objects.
grid_arrange_shared_legend <- function(..., ncol = 2) {
  plots <- list(...)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = "bottom", legend.title = element_blank()))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  
  p <- lapply(plots, function(x)
    ggplotGrob(x + theme(legend.position="none")))
  nplots <- length(p)
  nrow <- nplots/ncol
  
  rows <- lapply(seq(1, nplots, by = ncol), function(np) do.call(cbind, c(p[np + seq(0, ncol-1)], size = "max")))
  cols <- do.call(rbind, c(rows, size = "max"))
  
  grid.arrange(
    # do.call(arrangeGrob, lapply(plots, function(x)
    #   x + theme(legend.position="none"))),
    cols,
    legend,
    ncol = 1,
    heights = grid::unit.c(unit(1, "npc") - lheight, lheight))
}





#' get the number of subgroups from a list (method) of lists (data set)
#'
#' @param all_methods list of lists of palmtrees, (g)lmtrees, OptimalClass' and cv.glmnets.
#'
#' @return RETURN sim_eval: data frame with simulation results
get_nsubgroups_eval <- function(all_methods) {
  se <- ldply(all_methods[["palmtree"]], function(x) {
    as.data.frame(attr(x$data, "simulation")[c("delta_beta", "nobs", "qualitative", 
                                               "npc", "npred", "nprog")])
  })
  type <- factor(rep(names(all_methods), each = nrow(se)),
                 levels = names(all_methods))
  # type <- factor(rep(c("palmtree", "palmtree1", "lmtree1", "lmtree2", "otr", "otr2", "lasso"), each = nrow(se)),
  #                levels = c("palmtree", "palmtree1", "lmtree1", "lmtree2", "otr", "otr2", "lasso"))
  sim_eval <- cbind(type = type, se)
  
  sim_eval$nsubgroups[sim_eval$type == "palmtree"] <- sapply(all_methods[["palmtree"]], 
                                                             function(x) width(x$tree))
  sim_eval$nsubgroups[sim_eval$type == "palmtree1"] <- sapply(all_methods[["palmtree1"]], 
                                                              function(x) width(x$tree))
  sim_eval$nsubgroups[sim_eval$type == "lmtree1"] <- sapply(all_methods[["lmtree1"]], 
                                                            function(x) width(x))
  sim_eval$nsubgroups[sim_eval$type == "lmtree2"] <- sapply(all_methods[["lmtree2"]], 
                                                            function(x) width(x))
  sim_eval$nsubgroups[sim_eval$type == "otr"] <- sapply(all_methods[["otr"]], 
                                                        function(x) length(unique(classif(x)@fitObj$where)))
  sim_eval$nsubgroups[sim_eval$type == "otr2"] <- sapply(all_methods[["otr2"]], 
                                                         function(x) width(classif(x)@fitObj))
  return(sim_eval)
}




#' Compute adjusted Rand Index
#'
#' @param x grouping 1.
#' @param y grouping 2.
#'
#' @return RETURN adjusted Rand Index for the two groupings
adj_rand_index <- function(x, y) {
  
  tab <- table(x, y)
  if(all(dim(tab) == c(1, 1))) return(1)
  
  a <- rowSums(tab)
  b <- colSums(tab)
  
  M <- sum(choose(tab, 2))
  N <- choose(length(x), 2)
  A <- sum(choose(a, 2))
  B <- sum(choose(b, 2))
  
  (M - (A * B) / N) / (0.5 * (A + B) - (A * B) / N)
}



#' Rand index from a list (method) of lists (data set)
#'
#' @param all_dat DESCRIPTION.
#' @param all_methods list of lists of palmtrees, (g)lmtrees and OptimalClass' (not possible for cv.glmnets).
#' @param type method. Names of the list elements.
#' @param j index for element in list of methods and data.frames.
#'
#' @return adjusted rand index between predicted and true groups
get_ari <- function(all_dat, all_methods, type, j) {
  
  true_group <- all_dat[[j]]$group
  
  if(type == "otr") {
    ### trick from 
    ### http://stackoverflow.com/questions/5102754/search-for-corresponding-node-in-a-regression-tree-using-rpart
    tr_fake <- all_methods[[type]][[j]]@classif@fitObj
    tr_fake$frame$yval <- as.numeric(rownames(tr_fake$frame))
    est_group <- predict(tr_fake, newdata = all_dat[[j]], type = "vector")
  } else if(type == "otr2") {
    tr_fake <- all_methods[[type]][[j]]@classif@fitObj
    est_group <- predict(tr_fake, newdata = all_dat[[j]], type = "node")
  } else {
    est_group <- predict(all_methods[[type]][[j]], newdata = all_dat[[j]], type = "node")
  }
  
  adj_rand_index(true_group, est_group)
}



#' mean difference on outcome scale
#'
#' @param x object of class palmtree, (g)lmtree or cv.glmnet.
#' @param newdata data.
#'
#' @return mean_benefitpred_err_raw and the mean_benefitpred_err_absolute
comp_mean_benefitpred_err <- function(x, newdata) {
  
  newdata1 <- newdata
  newdata1$a <- factor("1", levels = c("0", "1"))
  newdata0 <- newdata
  newdata0$a <- factor("0", levels = c("0", "1"))
  
  if("lm" %in% class(x)) { ### lm
    
    xnam <- grep("x", names(newdata), value = TRUE)
    fmla <- as.formula(paste("y ~ + a + ", paste("a *", xnam, collapse = " + ")))
    
    dx1 <- model.matrix(fmla, data = newdata1)
    dx1 <- dx1[, colnames(dx1) != "(Intercept)"]
    dx0 <- model.matrix(fmla, data = newdata0)
    dx0 <- dx0[, colnames(dx0) != "(Intercept)"]
    
    pr1 <- as.vector(predict(x, dx1, s = "lambda.min"))
    pr0 <- as.vector(predict(x, dx0, s = "lambda.min"))
    
  } else { ### trees
    
    pr1 <- predict(x, newdata = newdata1, type = "response")
    pr0 <- predict(x, newdata = newdata0, type = "response")
    
  }
  
  pr10 <- pr1 - pr0
  mu10 <- newdata$mu1 - newdata$mu0
  mu10pr10 <- mu10 - pr10
  cbind(mean_benefitpred_err_raw = mean(mu10pr10), mean_benefitpred_err_absolute = mean(abs(mu10pr10)))
}

