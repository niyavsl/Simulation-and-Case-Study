library("batchtools")
reg <- loadRegistry("bt_simulation_palmtree/", writeable = TRUE)
setDefaultRegistry(reg)

done <- findDone()
res <- reduceResultsDataTable(ids = done)
results0 <- ijoin(getJobPars(ids = res$job.id), res)
results1 <- ijoin(results0, getJobTags(res$job.id))
results <- ijoin(getJobStatus(ids = res$job.id), results1)

names(results)
table(results$type)
table(results$type, results$tags, useNA = "always")
table(results$type, results$repl, useNA = "always")
results$qualitative <- as.numeric(results$qualitative)
save(results, file = "sim_results.RData")

ex <- findExperiments(algo.name = "stima", repls = 1:2)
tab <- getJobPars(ids = ex)
# estrn <- estimateRuntimes(tab)

