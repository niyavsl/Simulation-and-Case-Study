source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\dgp.R")
source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\methods.R")
source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\evaluation.R")


## ----sim_setup--------------------------------
library("palmtree")
library("partykit")
library("palmtree")
library("plyr")
library("batchtools")
library("DynTxRegime")
library("rpart")
library("stima")
reg <- loadRegistry("bt_simulation_palmtree/")
setDefaultRegistry(reg)

## allow for parallel computing, for other options see ?makeClusterFunctions
reg$cluster.functions = makeClusterFunctionsSocket(ncpus = parallel::detectCores() - 2)
# reg$cluster.functions = makeClusterFunctionsMulticore(ncpus = 13)


## ----sim_standard--------------------------------
# run only the standard scenarios
all <- findNotSubmitted()
stand <- findTagged(tags = "standard")
rstandard <- ijoin(all, stand)
submitJobs(rstandard)


## ----sim_npred0--------------------------------
# run only the npred = 0 scenarios with nobs changing
all <- findNotDone()
null <- findTagged(tags = "null_varnobs")
rnpred0 <- ijoin(all, null)
submitJobs(rnpred0)

## ----sim_repl12--------------------------------
# run only the first two replictates of each experiment
all <- findNotDone()
rep12_all <- findExperiments(repls = 1:2)
rep12 <- ijoin(all, rep12_all)
submitJobs(rep12)


## run remaining jobs
# submitJobs(findNotSubmitted())

waitForJobs()

sessionInfo()
# R version 3.4.1 (2017-06-30)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: Ubuntu 16.04.2 LTS
# 
# Matrix products: default
# BLAS: /usr/lib/libblas/libblas.so.3.6.0
# LAPACK: /usr/lib/lapack/liblapack.so.3.6.0
# 
# locale:
# [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C              
# [3] LC_TIME=de_CH.UTF-8        LC_COLLATE=en_US.UTF-8    
# [5] LC_MONETARY=de_CH.UTF-8    LC_MESSAGES=en_US.UTF-8   
# [7] LC_PAPER=de_CH.UTF-8       LC_NAME=C                 
# [9] LC_ADDRESS=C               LC_TELEPHONE=C            
# [11] LC_MEASUREMENT=de_CH.UTF-8 LC_IDENTIFICATION=C       
# 
# attached base packages:
# [1] grid      stats     graphics  grDevices utils     datasets  methods  
# [8] base     
# 
# other attached packages:
# [1] stima_1.1         rpart_4.1-11      DynTxRegime_2.1   modelObj_3.0     
# [5] batchtools_0.9.3  data.table_1.10.4 plyr_1.8.4        palmtree_0.0-0   
# [9] partykit_1.2-0    mvtnorm_1.0-6     libcoin_0.9-3    
# 
# loaded via a namespace (and not attached):
# [1] Rcpp_0.12.12      Formula_1.2-2     magrittr_1.5      splines_3.4.1    
# [5] progress_1.1.2    rappdirs_0.3.1    lattice_0.20-35   R6_2.2.2         
# [9] brew_1.0-6        tools_3.4.1       parallel_3.4.1    checkmate_1.8.3  
# [13] base64url_1.2     survival_2.41-3   digest_0.6.12     assertthat_0.2.0 
# [17] Matrix_1.2-10     stringi_1.1.5     compiler_3.4.1    backports_1.1.0  
# [21] prettyunits_1.0.2

