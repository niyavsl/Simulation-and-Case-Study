#' Terminal panel plot function for palmtree
#'
#' Plots a table of parameter estimates
#'
#' @param obj a partynode object.
#' @param fixed_coefs the estimates of the fixed parameters.
#'        A vector or a matrix (if confidence intervals are provided).
plot.terminal.palmtree <- function(obj, data, fixed_coefs, extreme_sg_coefs) {
  pushViewport(viewport(x = unit(0.5, "npc"), y = unit(0.9, "npc"),
                        just = "top"))
  fill_header <- NULL
  rnd <- 2

  ## data for plot
  outc <- names(data)[[1]]
  trt <- attributes(obj$info$object$terms)$term.labels
  nodeid <- id_node(obj)
  tdat <- data[data$.tree == nodeid, ]


  ## coefficients
  ch_coefs <- coef(obj$info)
  if(is.matrix(fixed_coefs)) { # if confint should be printed
    ch_coefs <- cbind(Estimate = ch_coefs, confint(obj$info$object))
    fill_header <- "white"
  }
  cf <- rbind(as.matrix(ch_coefs), as.matrix(fixed_coefs))
  which.color <- apply(sign(cf), 1, sum) + 5
  cf <- format(round(cf, rnd), nsmall = rnd)
  # if(is.matrix(fixed_coefs)) cf <- cbind(estimate = cf[, "estimate"], CI = paste0("(", paste(cf[,"2.5 %"], cf[, "97.5 %"], sep = ", "), ")"))
  colnames(cf) <- gsub(" ", "", colnames(cf))

  ## table
  # mypalette <- brewer.pal(11, "PiYG")
  # sq <- seq(-1, 1, length.out = length(mypalette))
  # which.color <- sapply(coef(obj$info) / extreme_sg_coefs, function(x) which.min(abs( x - sq )))
  mypalette <- brewer.pal(9, "PiYG")
  fill_lines <- mypalette[which.color]
  fill_rowheads <- rep("white", times = 3)
  font_rowheads <- c("plain", "bold", "bold", "plain")
  tb <- tableGrob(cf,
                  theme = ttheme_default(
                    core = list(fg_params = list(hjust = 1, x = 0.9),
                                bg_params = list(fill = fill_lines)),
                    colhead = list(bg_params = list(fill = "white")),
                    rowhead = list(fg_params = list(fontface = font_rowheads),
                                   bg_params = list(fill = c(fill_header, fill_rowheads)))
                  )
  )



  ## box around table
  g <- gtable::gtable_add_grob(tb,
                               grobs = rectGrob(gp = gpar(fill = NA, lwd = 2, col = "gray")),
                               t = 1, b = nrow(tb), l = 1, r = ncol(tb))



  ## table plus plot
  xticks <- paste0(levels(tdat[, trt]), "\n(n=", table(tdat[, trt]), ")")
  p <- ggplot(tdat, aes_string(y = outc, x = trt)) +
    geom_boxplot() +
    theme_bw() +
    stat_summary(fun.y = mean, geom = "point", shape = 18,
                 size = 4, color = "#908f8f") +
    scale_x_discrete(labels = xticks)

  gp <- arrangeGrob(p, g, ncol = 1, heights = unit(c(0.55, 0.45), "npc"),
                    widths = sum(g$widths))
  yj <- unit(0.5,"npc") #- 0.1*sum(gp$heights)
  gp$vp <- viewport(y = yj, height = sum(gp$heights))
  grid.draw(gp)

  ## node number
  pushViewport(gp$vp)
  wid <- unit(1.3, "strwidth", as.character(nodeid))
  hei <- unit(1.3, "strheight", as.character(nodeid))
  nodeIDvp <- viewport(x = unit(0.5, "npc"), y = unit(1, "npc") + 0.8*hei,
                       just = c("centre", "top"),
                       width = max(unit(1, "lines"), wid),
                       height = max(unit(1, "lines"), hei))
  pushViewport(nodeIDvp)
  grid.rect(gp = gpar(fill = "white"))
  grid.text(id_node(obj))

  upViewport(3)
}



#' Plot method for palmtree objects
#'
#' @param x an object of class palmtree.
#' @param confint a logical indicating if confidence intervals should
#'        be included in the terminal table.
#' @param ... further arguments passed to plot.lmtree or plot.glmtree.
plot.palmtree <- function(x, confint = FALSE, colors = TRUE, ...) {
  ## for color coding of subgroup coefficients
  sg_coefs <- coef(x, model = "tree")
  if(is.matrix(sg_coefs)) {
    extreme <- apply(sg_coefs, 2, function(x) max(abs(x)))
  } else {
    extreme <- sg_coefs
  }

  ## fixed coefficients
  fixed_coefs <- coef(x, model = "palm")
  if(confint == TRUE) {
    fixed_coefs <- cbind(estimate = fixed_coefs, t(confint(x$palm)[names(fixed_coefs),]))
  }

  ## data needed
  fml <- Formula::as.Formula(x$formula)
  mp <- Formula::model.part(fml, data = x$data, lhs = 1, rhs = 1)
  mp$.tree <- x$data$.tree

  ## plot
  plot.terminal <- function(obj) {
    plot.terminal.palmtree(obj, data = mp,
                           fixed_coefs = fixed_coefs,
                           extreme_sg_coefs = extreme)
  }
  plot(x$tree, terminal_panel = plot.terminal, ...)
}



