## ----dgp-----------------------------------------------------------------
##' data generating process
##' 
##' @param cutpoint split points where predictive variables cause a jump in treatment effect.
##'        If NULL, this will be 0 for all.
##' @param delta_beta distance between the treatment effects in the different subgroups
##' @param corpc correlation between patient characteristics
##' @param sd standard deviation 
##' @param nobs number of observations
##' @param qualitative logical. Should the treatment effects have a qualitative difference or
##'        just a quantitative difference.
##' @param npc number of patient characteristics
##' @param npred number of predictive patient characteristics 
##'        (except interatction_scenario 3, npred fixed to 2)
##' @param nprog number of prognostic patient characteristics
##' @param eff_prog effect size of the prognostic variables
##' @param interaction_scenario one of 1, 2 or 3. 
##' 1 is that only the leftmost true subgroup can have a negative effect (if qualitative = TRUE) 
##' and to every subgroup going further to the right the effect gets bigger (by delta_beta). 
##' 2 is the other way around.
##' 3 is a more complex structure with 2 prognostic factors with 
##' eff_trt <- c(k, k + delta_beta, 2*k + delta_beta, k + 2*delta_beta)
##' @param overlap How many factors should be predictive and prognostic at the same time? 
##' Default is 0. 
dgp <- function(cutpoint = NULL, delta_beta = 0.5, corpc = 0.2, sd = 1.5,
                nobs, qualitative, npc, npred, nprog, eff_prog,
                interaction_scenario = 1, overlap = 0) {
  
  stopifnot(overlap <= min(npred, nprog)) 
  
  simulation <- as.list(environment())
  
  ## patient characteristics
  x <- mvtnorm::rmvnorm(nobs, mean = rep(0, npc), 
                        sigma = diag(1 - corpc, npc) + corpc)
  colnames(x) <- paste0("x", 1:npc)
  d <- as.data.frame(x)
  
  ## treatment a
  d$a <- rbinom(nobs, size = 1, prob = 0.5)
  
  ## error term
  d$err <- rnorm(nobs, mean = 0, sd = sd)
  
  
  
  if(interaction_scenario == 3) { ##--- interaction_scenario 3
    
    ## predictive and prognostic factors
    which_pred <- c(1, 2, 2)
    start_prog <- ifelse(npred > 0, max(which_pred) - overlap, 0)
    which_prog <- start_prog + seq_len(nprog) 
    
    ## define subgroups
    if(npred > 0) { 
      if(is.null(cutpoint)) cutpoint <- c(0, qnorm(0.33), qnorm(0.66))
      rules <- t(t(x[, which_pred]) > cutpoint)
      d$group <- factor(ifelse(rules[, 1], 1, 3) +
                          ifelse(rules[, 2], 0, rules[, 1]) +
                          ifelse(rules[, 3], 0, !rules[, 1]))
    } else {
      d$group <- factor(1)
    }
    
    ## response function mu
    k <- ifelse(qualitative, -3/4 * delta_beta, 0.5)
    eff_trt <- c(k, k + delta_beta, 2*k + delta_beta, k + 2*delta_beta)
    
  } else { ##--- interaction_scenario 1 and 2
    
    ## predictive and prognostic factors
    which_pred <- seq_len(npred)  # if there are predictive factors they start with x1
    start_prog <- ifelse(npred > 0, max(which_pred) - overlap, 0)
    which_prog <- start_prog + seq_len(nprog) 
    
    ## define subgroups
    if(npred > 0) { 
      if(is.null(cutpoint)) cutpoint <- rep(0, npred)
      rules <- t(t(x[, which_pred]) > cutpoint)
      nrules <- rowSums(rules)
      thisrule <- sapply(seq_len(length(nrules)), 
                         function(i) all(rules[i, seq_len(nrules[i])] == TRUE))
      
      if(length(unique(nrules*thisrule)) != npred + 1) 
        warning("there are not as many subgroups as should be")
      
      d$group <- factor(nrules*thisrule, levels = seq_len(npred + 1)-1)
    } else {
      d$group <- factor(1)
    }
    
    ## response function mu
    if(length(delta_beta) == 1) delta_beta <- cumsum(c(0, rep(delta_beta, npred)))
    k <- ifelse(qualitative, -3/4 * min(delta_beta[delta_beta != 0]), 0.5)  
    eff_trt <- k + delta_beta
    # for interaction scenario 2 reverse eff_trt
    if(interaction_scenario == 2) eff_trt <- rev(eff_trt)
    
  }
  
  eff_signs <- range(sign(eff_trt))
  if(all(eff_signs <= 0)) 
    stop("delta_beta must be defined in a way that 
         there can be a qualitative treatment effect")
  if(qualitative & (eff_signs[1] == eff_signs[2]))
    stop("The effect signs should differ since qualtitative is TRUE.")
  if(npred > 0) {
    modelmat <- model.matrix(~ group - 1, data = d)
  } else {
    modelmat <- as.matrix(rep(1, nobs))
  }
  d$trt_effect <- modelmat %*% eff_trt 
  d$mu0 <- as.vector( 0 + x[ , which_prog, drop = FALSE] %*% rep(eff_prog, times = nprog) )
  d$mu1 <- as.vector( d$mu0 + d$trt_effect)
  idmu <- cbind(seq_len(nrow(d)), d$a + 1)
  d$mu <- d[ , c("mu0", "mu1")][idmu]
  
  ## outcome y
  d$y <- d$mu + d$err
  
  simulation$eff_trt <- eff_trt
  simulation$which_pred <- which_pred
  simulation$which_prog <- which_prog
  simulation$cutpoint <- cutpoint
  attr(d, "simulation") <- simulation
  d$a <- factor(d$a)
  return(d)
  
}


