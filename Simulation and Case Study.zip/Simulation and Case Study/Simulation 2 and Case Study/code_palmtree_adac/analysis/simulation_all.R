source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\dgp.R")
source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\methods.R")
source("C:\\Users\\newsh\\Downloads\\code_palmtree_adac\\analysis\\basis\\evaluation.R")




## ----sim_setup--------------------------------
library("palmtree")
library("partykit")
library("palmtree")
library("plyr")
library("batchtools")
library("DynTxRegime")
library("rpart")
library("stima")



## create the experiment registry
reg = makeExperimentRegistry(
  file.dir = "bt_simulation_palmtree",
  packages= c("palmtree", "DynTxRegime", "rpart", "stima"),
  seed = 123)

## allow for parallel computing, for other options see ?makeClusterFunctions
reg$cluster.functions = makeClusterFunctionsSocket(ncpus = parallel::detectCores() - 2)



## ----sim_2_data-----------------------
fixed2 <- list(cutpoint = NULL, corpc = 0.2, sd = 1, eff_prog = 1)

## what happens if there are NO predictive factors?
sc1grid <- expand.grid(
  delta_beta = 0.5,
  nobs = cumsum(c(100, rep(200, 4))),
  qualitative = c(FALSE),
  npc = c(10 * c(1, 3, 5, 7)),
  npred = 0,
  nprog = 1:4
)

## what happens if there ARE predictive factors?
sc2grid <- expand.grid(
  delta_beta = seq(0.1, 1.5, by = 0.2),
  nobs = cumsum(c(100, rep(200, 4))),
  qualitative = c(TRUE, FALSE),
  npc = c(10 * c(1, 3, 5, 7)),
  npred = 1:4,
  nprog = 1:4
)

scgrid <- rbind(sc1grid, sc2grid)


addProblem("datagen", 
           fun = function(data, job, 
                          delta_beta, nobs, qualitative, npc, npred, nprog,
                          interaction_scenario = 1, cutpoint = NULL, corpc = 0.2, sd = 1, eff_prog = 1, # fixed
                          ...) {
             train <- dgp(delta_beta = delta_beta, nobs = nobs, 
                          qualitative = qualitative, npc = npc, npred = npred, 
                          nprog = nprog, interaction_scenario = interaction_scenario,
                          cutpoint = cutpoint, corpc = corpc, sd = sd, 
                          eff_prog = eff_prog)
             test <- dgp(delta_beta = delta_beta, nobs = nobs, 
                         qualitative = qualitative, npc = npc, npred = npred, 
                         nprog = nprog, interaction_scenario = interaction_scenario,
                         cutpoint = cutpoint, corpc = corpc, sd = sd, 
                         eff_prog = eff_prog)
             list(train = train, test = test)
           })

pdes <- list(datagen = scgrid)




## ----sim_2_apply-------
tree.wrapper <- function(data, job, instance, type, method, minsplit, alpha, ...) {
  
  mod <-  comp_tree(data = instance$train, method = method, model = FALSE,
                    minsplit = 40, alpha = 0.05, ...)
  get_evaluations(mod, newdata = instance$test, method = method)
  
}
addAlgorithm(name = "tree", fun = tree.wrapper)

otr.wrapper <- function(data, job, instance, type = "otr", ...) {
  
  mod <- comp_otr(data = instance$train, classifier = "rpart")
  get_evaluations(mod, newdata = instance$test, method = "otr")
  
}
addAlgorithm(name = "otr", fun = otr.wrapper)

stima.wrapper <- function(data, job, instance, ...) {
  mod <- comp_stima(data = instance$train)
  get_evaluations(mod, newdata = instance$test, method = "stima")
}
addAlgorithm(name = "stima", fun = stima.wrapper)


## algorithm design
ades <- list(tree = data.frame(type = c("palmtree","lmtree1", "lmtree2"), 
                               method = c("palmtree","lmtree", "lmtree"), 
                               v = c(1, 1, 2), 
                               stringsAsFactors = FALSE),
             otr = data.frame(type = "otr"),
             stima = data.frame(type = "stima"))


## add experiments
addExperiments(pdes, ades, repls = 150)
summarizeExperiments()
# testJob(id = findExperiments(algo.name = "stima", prob.pars = (npc == 30))$job.id[[100]])


#### add tags
## standard simulation settings
all_pars <- getJobPars()
is_standard <- all_pars[, list((delta_beta = 0.5), 
                               (nobs = 300),
                               (qualitative = TRUE),
                               (npc = 30),
                               (npred = 2),
                               (nprog = 2)) ]
nstandard <- rowSums(is_standard)
standard_pars <- all_pars[nstandard >= (max(nstandard) - 1), ]
addJobTags(ids = standard_pars$job.id, tags = "standard")
sc <- is_standard[nstandard >= (max(nstandard) - 1), ]
standard_pars$scenario <- apply(sc, 1, function(x) {
  ret <- which(!x)
  if(length(ret) == 0) {
    ret <- "all"
  } else {
    ret <- c("delta_beta", "nobs", "qualitative", "npc", "npred", "nprog")[ret]
  }
  return(ret)
})
addt <- function(x) addJobTags(ids = x$job.id, 
                               tags = unique(x$scenario))
library("plyr")
dlply(standard_pars, .(scenario), addt, .progress = "text")

## no subgroups setting with varying nobs
npred0 <- all_pars[(npred = 0) &
                     (delta_beta = 0.5) &
                     (qualitative = FALSE) &
                     (npc = 30) &
                     (nprog = 2), ]
addJobTags(ids = npred0$job.id, tags = "null_varnobs")
