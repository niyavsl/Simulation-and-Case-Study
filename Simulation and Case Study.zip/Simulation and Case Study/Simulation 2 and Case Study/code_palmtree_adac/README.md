All files in this folder are a clean version of the original files that were
used for the analysis and simulation study. The entire paper can be reproduced
in this way. 

simulation.R, application.R and appendix.R were extracted from the Rnw files:

library("knitr")
purl("simulation.Rnw")
purl("application.Rnw")
purl("appendix.Rnw")





# Math exam

## application.R 
Compute and visualise PALM tree for Mathematics Exam data.




# Simulation study

The entire simulation study is available in folder analysis, which contains a
Makefile. To run all codes (please see WARNING below) and retrieve the results,
run:

make all

This will run:

1. simulation_all.R    
Simulation setup with batchtools package

2. simulation_all_run.R    
Run all simulation scenarios ran for the manuscript

3. simulation_results.R    
Retrieve results from batchtools simulation registry.
The resulting file is sim_results.RData


!!! **WARNING** !!!
Computations take several weeks.  We added sim_results.RData to the folder so
the computation does not need to be done. 


## simulation.R 
Visualise simulation results shown in manuscript.


## appendix.R 
Visualise simulation results shown in appendix.


